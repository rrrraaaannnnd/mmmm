
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-my-appointments',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './my-appointments.html',
  styleUrl: './my-appointments.css'
})
export class MyAppointments {
  doctor = '';
  date = '';
  time = '';
  reason = '';

  constructor(private router: Router) {
    const appointment = history.state;

    this.doctor = appointment.doctor || '';
    this.date = appointment.date || '';
    this.time = appointment.time || '';
    this.reason = appointment.reason || '';
  }

  cancelAppointment() {
    if (confirm('Are you sure you want to cancel this appointment?')) {
      this.doctor = '';
      this.date = '';
      this.time = '';
      this.reason = '';

      alert('Appointment cancelled successfully.');
    }
  }

  bookAppointment() {
    this.router.navigate(['/appointment-booking']);
  }
}
